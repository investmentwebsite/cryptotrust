import React, { useState } from 'react';

export default function Fund() {
  const [proof, setProof] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  const handleUpload = (e) => {
    e.preventDefault();
    if (proof) {
      console.log('Uploading proof:', proof.name);
      setSubmitted(true);
    }
  };

  return (
    <div>
      <h2>Fund Wallet</h2>
      <p>Send USDT (TRC20) to: <strong>TQCWpycvkpbNELXgP6NbLNJgnBSvujyiRP</strong></p>
      <form onSubmit={handleUpload}>
        <input type="file" accept="image/*" onChange={(e) => setProof(e.target.files[0])} required />
        <button type="submit">Submit Proof</button>
      </form>
      {submitted && <p>Proof submitted. Awaiting manual approval.</p>}
    </div>
  );
}

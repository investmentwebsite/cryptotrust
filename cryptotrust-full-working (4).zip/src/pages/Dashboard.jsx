import React from 'react';

export default function Dashboard() {
  return (
    <div>
      <h2>User Dashboard</h2>
      <p>Welcome to your dashboard.</p>
    </div>
  );
}

# CryptoTrust

A simple crypto investment frontend built with React.
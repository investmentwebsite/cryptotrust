import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCg16MmMLtB-tuyc007M0Syq9QQU_NMbY8",
  authDomain: "cryptotrust-42ec1.firebaseapp.com",
  projectId: "cryptotrust-42ec1",
  storageBucket: "cryptotrust-42ec1.appspot.com",
  messagingSenderId: "390403056698",
  appId: "1:390403056698:web:8fc312c6e89ba60f667d98",
  measurementId: "G-SD3F7Q3BQY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMode, setAuthMode] = useState('login');
  const [info, setInfo] = useState({});

  useEffect(() => {
    onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const snap = await getDoc(doc(db, 'users', currentUser.uid));
        if (snap.exists()) setInfo(snap.data());
      } else {
        setInfo({});
      }
    });
  }, []);

  const handleAuth = async () => {
    try {
      if (authMode === 'signup') {
        const res = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', res.user.uid), {
          email,
          plan: 'Starter',
          balance: 0
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (e) {
      alert(e.message);
    }
  };

  const handleLogout = () => signOut(auth);

  return (
    <div style={{ color: 'white', backgroundColor: '#0d1117', minHeight: '100vh', padding: 20 }}>
      <h1>CryptoTrust Investments</h1>
      {user ? (
        <div>
          <p>Welcome, {user.email}</p>
          <p>Plan: {info.plan}</p>
          <p>Balance: ${info.balance}</p>
          <button onClick={handleLogout}>Logout</button>
        </div>
      ) : (
        <div>
          <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} /><br/>
          <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} /><br/>
          <button onClick={handleAuth}>{authMode === 'login' ? 'Login' : 'Sign Up'}</button>
          <p>
            {authMode === 'login' ? (
              <>No account? <button onClick={() => setAuthMode('signup')}>Sign up</button></>
            ) : (
              <>Have an account? <button onClick={() => setAuthMode('login')}>Login</button></>
            )}
          </p>
        </div>
      )}
    </div>
  );
}

export default App;

import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="bg-white text-gray-900 min-h-screen px-6 py-10">
      <header className="flex justify-between items-center mb-10">
        <h1 className="text-2xl font-bold">CryptoTrust</h1>
        <nav className="space-x-4">
          <Link to="/dashboard" className="text-blue-600 hover:underline">Dashboard</Link>
          <Link to="/fund" className="text-blue-600 hover:underline">Fund Wallet</Link>
        </nav>
      </header>

      <main className="text-center max-w-2xl mx-auto">
        <h2 className="text-4xl font-extrabold mb-6">Invest in the Future of Crypto</h2>
        <p className="text-lg text-gray-600 mb-8">
          CryptoTrust is a secure and trusted crypto investment platform that helps you grow your portfolio.
        </p>
        <Link to="/dashboard" className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold">
          Get Started
        </Link>
      </main>

      <footer className="mt-20 text-center text-gray-400 text-sm">
        &copy; {new Date().getFullYear()} CryptoTrust. All rights reserved.
      </footer>
    </div>
  );
}
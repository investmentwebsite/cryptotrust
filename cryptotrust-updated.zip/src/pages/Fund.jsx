import React, { useState } from 'react';

export default function Fund() {
  const [proof, setProof] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  const handleUpload = (e) => {
    e.preventDefault();
    if (proof) {
      console.log('Uploading:', proof.name);
      setSubmitted(true);
    }
  };

  return (
    <div className="bg-white text-gray-900 min-h-screen px-6 py-10">
      <h2 className="text-2xl font-bold mb-6">Fund Your Wallet</h2>
      <p className="mb-4 text-lg">Send USDT to the address below (TRC20):</p>
      <div className="mb-6 bg-gray-100 p-4 rounded-lg font-mono">TQCWpycvkpbNELXgP6NbLNJgnBSvujyiRP</div>
      <form onSubmit={handleUpload} className="space-y-4">
        <label className="block">
          Upload Screenshot Proof:
          <input type="file" accept="image/*" onChange={(e) => setProof(e.target.files[0])} required />
        </label>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Submit Proof
        </button>
      </form>
      {submitted && <p className="mt-4 text-green-600">Proof submitted. Awaiting manual approval.</p>}
    </div>
  );
}
